# JOB-A-THON---January-2023---analyticsvidhya.com
predicted customer lifetime value for issurance company

JOB - A - THON link : https://datahack.analyticsvidhya.com/contest/job-a-thon-january-2023/#About
